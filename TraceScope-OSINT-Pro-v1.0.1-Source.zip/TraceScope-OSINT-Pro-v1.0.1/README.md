# TraceScope OSINT Pro v1.0.1

Android için **kaynak-temelli, kamuya açık veri odaklı OSINT** uygulaması. Bu proje Aegis/QuantDesk projelerinden ayrı bir uygulamadır.

## Ayrı uygulama kimliği

- Uygulama adı: `TraceScope OSINT Pro`
- Android applicationId: `com.tracescope.osint`
- Önerilen GitHub deposu: `TraceScope-OSINT-Android`
- APK artifact: `TraceScope-OSINT-Pro-v1.0.1-APK`

Bu nedenle Aegis OSINT veya QuantDesk ile aynı telefona ayrı uygulama olarak kurulabilir.

## Modüller

- **Telefon araştırması:** E.164/ulusal/uluslararası biçim, olası/geçerli durum, hat türü, numara bölgesi, operatör ve saat dilimi sinyali.
- **Kullanıcı adı araştırması:** akıllı varyasyonlar, çoklu platform taraması, engel/rate-limit izolasyonu, açık profil metadatasından e-posta/telefon/konum/web sitesi sinyalleri.
- **E-posta araştırması:** biçim, alan adı, kullanıcı adı adayları ve açık web pivotları.
- **E-posta ↔ Telefon Korelasyonu:** Gmail, Outlook/Hotmail/Live, Yahoo, Proton ve kurumsal alan adları için çift yönlü açık-web korelasyon sorguları.
- **IP:** yalnızca zaten bilinen IP için yaklaşık ağ konumu, ISP ve ASN.
- **Kimlik korelasyonu:** ortak açık e-posta, telefon, alan adı, görünen ad, kullanıcı adı ve konum sinyallerinden açıklanabilir skor.
- **PDF/JSON rapor:** sorgu ve kaynak sinyallerini dışa aktarır.

## E-posta ↔ Telefon mantığı

### Telefon → e-posta
Numara farklı açık gösterim biçimlerine normalize edilir. Gmail, Hotmail/Outlook/Live ve genel e-posta/iletişim sorguları hazırlanır. Sonuç ancak kamuya açık sayfada yayımlanmışsa bulgu kabul edilmelidir.

### E-posta → telefon
E-posta exact-search, iletişim sayfaları, sosyal profil izleri ve e-posta yerel kısmından türetilen kullanıcı adı varyasyonlarıyla araştırılır.

Bu modül **Google/Microsoft hesabının gizli kurtarma telefonunu veya gizli kayıt e-postasını çıkarmaz** ve erişim kontrolünü aşmaz.

## Sonuç güvenilirliği

Tek başına HTTP 200 “hesap bulundu” değildir. Sonuçlar `Doğrulandı / Muhtemel / Belirsiz / Tarayıcı doğrulaması / Bulunamadı / Hata` olarak ayrılır. Bir servis hata verirse diğer kaynaklar devam eder.

## Build doğrulaması

GitHub Actions sırası:

1. JDK 17
2. Gradle 8.9
3. Unit test
4. Android Lint
5. Debug APK
6. Lint raporu + APK artifact

Lint uyarıları hata sayılmaz; gerçek lint **error** varsa build durur. Böylece sorun gizlenmez. Lint raporu ayrıca artifact olarak saklanır.

## Güvenlik

- Yalnızca `INTERNET` izni.
- Cleartext HTTP kapalı.
- Otomatik araştırma geçmişi yok.
- Gizli kayıt bilgisi, parola/OTP, özel mesaj, erişim kontrolü aşma veya canlı GPS özelliği yok.
