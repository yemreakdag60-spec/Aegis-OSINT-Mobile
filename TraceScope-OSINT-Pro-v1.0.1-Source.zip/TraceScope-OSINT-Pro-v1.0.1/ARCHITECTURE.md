# TraceScope OSINT Pro — Mimari

## Katmanlar

- `engine/`: telefon, e-posta, kullanıcı adı, IP ve e-posta↔telefon korelasyon motorları.
- `model/`: güven, kaynak, profil ve korelasyon veri modelleri.
- `report/`: PDF/JSON dışa aktarma.
- `ui/`: Jetpack Compose tabanlı tek-activity arayüz.
- `TraceScopeViewModel`: araştırma akışı ve hata izolasyonu.

## Tasarım ilkeleri

1. **Açıklanabilir sonuç:** bulgu hangi URL/sinyal nedeniyle üretildiğini taşır.
2. **Hata izolasyonu:** tek kaynak hatası bütün taramayı düşürmez.
3. **Sahte kesinlik yok:** HTTP 200 tek başına doğrulama sayılmaz.
4. **Özel veriye erişim yok:** yalnızca kamuya açık/izinli kaynaklar.
5. **Bağımsız paket:** `com.tracescope.osint`, diğer Aegis/QuantDesk uygulamalarından ayrı kurulur.
6. **Kalite kapısı:** unit test + lint geçmeden APK artifact üretilmez.
