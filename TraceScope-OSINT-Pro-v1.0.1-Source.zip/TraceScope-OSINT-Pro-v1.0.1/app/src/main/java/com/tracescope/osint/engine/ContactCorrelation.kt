package com.tracescope.osint.engine

import com.tracescope.osint.model.ContactCorrelationIntel
import com.tracescope.osint.model.ContactDirection
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Public-source correlation helper.
 *
 * It never attempts to reveal private account-registration data. Instead it normalizes
 * the supplied public identifier and creates reproducible exact-search pivots that can
 * surface pages where a phone number and an e-mail address were published together.
 */
object ContactCorrelationEngine {
    fun analyze(input: String): ContactCorrelationIntel {
        val raw = input.trim()
        if (raw.isBlank()) {
            return ContactCorrelationIntel(
                input = input,
                direction = ContactDirection.EMAIL_TO_PHONE,
                normalizedInput = "",
                error = "Telefon numarası veya e-posta girin"
            )
        }

        return if ('@' in raw) emailToPhone(raw) else phoneToEmail(raw)
    }

    private fun emailToPhone(emailInput: String): ContactCorrelationIntel {
        val email = EmailEngine.analyze(emailInput)
        if (!email.valid) {
            return ContactCorrelationIntel(
                input = emailInput,
                direction = ContactDirection.EMAIL_TO_PHONE,
                normalizedInput = emailInput.trim(),
                error = email.error ?: "Geçersiz e-posta"
            )
        }

        val emailAddress = emailInput.trim().lowercase()
        val provider = providerLabel(email.domain)
        val user = email.localPart
        val candidates = UsernameVariantGenerator.generate(user, limit = 8)
        val userTerms = candidates.joinToString(" OR ") { "\"$it\"" }
        val pivots = listOf(
            "Exact e-posta + telefon" to google("\"$emailAddress\" (phone OR telephone OR mobile OR gsm OR telefon OR iletişim OR whatsapp)"),
            "Exact e-posta + iletişim sayfası" to google("\"$emailAddress\" (contact OR contacts OR iletişim OR hakkımızda)"),
            "Bing exact e-posta + telefon" to bing("\"$emailAddress\" (phone OR mobile OR gsm OR telefon OR iletişim)"),
            "Sosyal profil izi" to google("\"$emailAddress\" (site:github.com OR site:gitlab.com OR site:facebook.com OR site:instagram.com OR site:x.com OR site:linkedin.com)"),
            "Kullanıcı adı pivotu" to google("($userTerms) (phone OR email OR contact OR iletişim)")
        )

        return ContactCorrelationIntel(
            input = emailInput,
            direction = ContactDirection.EMAIL_TO_PHONE,
            normalizedInput = emailAddress,
            providerHint = provider,
            usernameCandidates = email.usernameCandidates,
            searchPivots = pivots,
            notes = listOf(
                "Sonuçlar yalnızca kamuya açık sayfalarda birlikte yayımlanmış iletişim izlerini hedefler.",
                "Gmail/Outlook/Hotmail hesaplarının gizli kurtarma telefonu bu yöntemle açığa çıkarılmaz.",
                "Aynı kaynakta e-posta ve telefonun birlikte görünmesi güçlü korelasyon sinyalidir; yine de kimlik doğrulaması değildir."
            )
        )
    }

    private fun phoneToEmail(phoneInput: String): ContactCorrelationIntel {
        val phone = PhoneEngine().analyze(phoneInput)
        if (!phone.possible && !phone.valid) {
            return ContactCorrelationIntel(
                input = phoneInput,
                direction = ContactDirection.PHONE_TO_EMAIL,
                normalizedInput = phoneInput.trim(),
                error = phone.error ?: "Geçerli/olası telefon numarası girin"
            )
        }

        val variants = listOf(phone.e164, phone.international, phone.national)
            .filter { it.isNotBlank() }.distinct()
        val exact = variants.joinToString(" OR ") { "\"$it\"" }
        val pivots = listOf(
            "Telefon + Gmail" to google("($exact) \"@gmail.com\""),
            "Telefon + Hotmail/Outlook" to google("($exact) (\"@hotmail.com\" OR \"@outlook.com\" OR \"@live.com\")"),
            "Telefon + tüm e-postalar" to google("($exact) (email OR e-posta OR eposta OR mail OR contact OR iletişim)"),
            "Bing telefon + e-posta" to bing("($exact) (email OR mail OR contact OR iletişim)"),
            "İşletme/kurum izi" to google("($exact) (site:linkedin.com OR site:facebook.com OR contact OR iletişim OR firma OR şirket)"),
            "Sosyal profil izi" to google("($exact) (site:instagram.com OR site:x.com OR site:tiktok.com OR site:github.com)")
        )

        return ContactCorrelationIntel(
            input = phoneInput,
            direction = ContactDirection.PHONE_TO_EMAIL,
            normalizedInput = phone.e164.ifBlank { phoneInput.trim() },
            providerHint = phone.carrier,
            phoneVariants = variants,
            searchPivots = pivots,
            notes = listOf(
                "Arama, numaranın farklı açık gösterim biçimlerini aynı sorguda kullanır.",
                "Bulunan e-posta ancak kaynak sayfada açıkça yayımlanmışsa sonuç kabul edilmelidir.",
                "Telefon numarasından Google/Microsoft hesabının gizli kayıt e-postası doğrudan elde edilemez."
            )
        )
    }

    private fun providerLabel(domain: String): String = when (domain.lowercase()) {
        "gmail.com", "googlemail.com" -> "Google / Gmail"
        "hotmail.com", "outlook.com", "live.com", "msn.com" -> "Microsoft / Outlook"
        "yahoo.com", "yahoo.com.tr" -> "Yahoo"
        "proton.me", "protonmail.com" -> "Proton"
        else -> if (domain.isBlank()) "" else "Özel/kurumsal alan adı: $domain"
    }

    private fun google(q: String) = "https://www.google.com/search?q=${enc(q)}"
    private fun bing(q: String) = "https://www.bing.com/search?q=${enc(q)}"
    private fun enc(v: String) = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
}
