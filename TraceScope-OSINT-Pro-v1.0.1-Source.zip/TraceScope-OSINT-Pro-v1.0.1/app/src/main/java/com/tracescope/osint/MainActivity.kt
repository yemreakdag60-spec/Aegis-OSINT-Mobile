package com.tracescope.osint

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tracescope.osint.engine.CorrelationEngine
import com.tracescope.osint.model.*
import com.tracescope.osint.report.ReportWriter
import com.tracescope.osint.ui.theme.TraceScopeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TraceScopeTheme { TraceScopeApp() } }
    }
}

private enum class AppTab(val label: String, val icon: ImageVector) {
    HOME("Ana Sayfa", Icons.Default.Home),
    SEARCH("Araştır", Icons.Default.Search),
    CORRELATION("Korelasyon", Icons.Default.Hub),
    REPORT("Rapor", Icons.Default.Description),
    SETTINGS("Ayarlar", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TraceScopeApp(vm: TraceScopeViewModel = viewModel()) {
    var tab by remember { mutableStateOf(AppTab.HOME) }
    val state by vm.state

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("TraceScope OSINT", fontWeight = FontWeight.Bold)
                            Text("Public-source intelligence", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                AppTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, item.label) },
                        label = { Text(item.label, maxLines = 1, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                AppTab.HOME -> HomeScreen(onSearch = { mode -> vm.setMode(mode); tab = AppTab.SEARCH }, result = state.result)
                AppTab.SEARCH -> SearchScreen(state, vm)
                AppTab.CORRELATION -> CorrelationScreen(state.result)
                AppTab.REPORT -> ReportScreen(state.result)
                AppTab.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
private fun HomeScreen(onSearch: (SearchMode) -> Unit, result: SearchBundle?) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HeroCard()
        }
        item {
            Text("Araştırma modülleri", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("Telefon", "Numara biçimi, bölge, operatör sinyali, web pivotları", Icons.Default.Phone, Modifier.weight(1f)) { onSearch(SearchMode.PHONE) }
                ModuleCard("Kullanıcı adı", "Varyasyonlar, platform tarama, açık temas/konum", Icons.Default.PersonSearch, Modifier.weight(1f)) { onSearch(SearchMode.USERNAME) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("E-posta", "Biçim, alan adı, kullanıcı adı adayları ve web pivotları", Icons.Default.Email, Modifier.weight(1f)) { onSearch(SearchMode.EMAIL) }
                ModuleCard("E-posta ↔ Telefon", "Gmail/Outlook dahil açık webde çift yönlü iletişim korelasyonu", Icons.Default.SyncAlt, Modifier.weight(1f)) { onSearch(SearchMode.CONTACT_LINK) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("IP", "Bilinen IP için yaklaşık ağ konumu ve ISP", Icons.Default.Language, Modifier.weight(1f)) { onSearch(SearchMode.IP) }
                ModuleCard("Korelasyon", "Hesaplar arası ortak açık sinyalleri puanlar", Icons.Default.Hub, Modifier.weight(1f)) { onSearch(SearchMode.USERNAME) }
            }
        }
        item {
            InfoCard(
                "Korelasyon motoru",
                "Farklı kullanıcı adlarını; görünen ad, ortak açık e-posta/telefon, web alan adı ve konum sinyalleriyle ilişkilendirir. Tek bir işareti kesin kimlik olarak kabul etmez.",
                Icons.Default.AccountTree
            )
        }
        item {
            InfoCard(
                "Kaynak-temelli rapor",
                "Her bulgu durum, güven seviyesi, URL, HTTP sonucu ve gecikme bilgisiyle kaydedilir. PDF/JSON dışa aktarma mevcuttur.",
                Icons.Default.FactCheck
            )
        }
        if (result != null) item {
            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Son araştırma", fontWeight = FontWeight.Bold)
                    Text("${result.mode.label}: ${result.query}")
                }
            }
        }
    }
}

@Composable
private fun HeroCard() {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, null, modifier = Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("TraceScope OSINT Pro", fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Açık kaynak araştırmasını tek akışta birleştirir", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Sahte kesinlik yerine kaynak, güven ve doğrulama mantığı kullanır. Gizli kayıt bilgisi, canlı GPS veya hesap ele geçirme işlevi içermez.")
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallBadge("HTTPS")
                SmallBadge("Kaynak izi")
                SmallBadge("Hata izolasyonu")
                SmallBadge("Rapor")
            }
        }
    }
}

@Composable
private fun SmallBadge(text: String) {
    Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = .12f)) {
        Text(text, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
    }
}

@Composable
private fun ModuleCard(title: String, subtitle: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier.clickable(onClick = onClick), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp).heightIn(min = 138.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f), maxLines = 4, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, icon: ImageVector) {
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(body, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchScreen(state: SearchUiState, vm: TraceScopeViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(SearchMode.entries) { mode ->
                    FilterChip(
                        selected = state.mode == mode,
                        onClick = { vm.setMode(mode) },
                        label = { Text(mode.label, fontSize = 12.sp) },
                        leadingIcon = { Icon(iconFor(mode), null, modifier = Modifier.size(17.dp)) }
                    )
                }
            }
        }
        item {
            OutlinedTextField(
                value = state.query,
                onValueChange = vm::setQuery,
                label = { Text(placeholderFor(state.mode)) },
                leadingIcon = { Icon(iconFor(state.mode), null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
        if (state.mode == SearchMode.USERNAME) item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Derin tarama", fontWeight = FontWeight.SemiBold)
                    Text("Varyasyon ve ikinci tur korelasyon taraması", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                }
                Switch(checked = state.deepScan, onCheckedChange = vm::setDeepScan)
            }
        }
        item {
            Button(onClick = vm::search, enabled = !state.loading, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                if (state.loading) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Kaynaklar taranıyor…")
                } else {
                    Icon(Icons.Default.Radar, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Araştırmayı başlat")
                }
            }
        }
        state.message?.let { msg -> item { AssistChip(onClick = {}, label = { Text(msg) }, leadingIcon = { Icon(Icons.Default.Info, null) }) } }
        item {
            Text("Yalnızca kamuya açık/izinli kaynaklar kullanılır. Otomatik erişimi engelleyen platformlar 'Tarayıcıda doğrula' olarak işaretlenir; sahte pozitif kesin hesap diye sunulmaz.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
        }
        state.result?.let { result ->
            when (result.mode) {
                SearchMode.PHONE -> result.phone?.let { p -> item { PhoneResultCard(p) } }
                SearchMode.EMAIL -> result.email?.let { e -> item { EmailResultCard(e) } }
                SearchMode.CONTACT_LINK -> result.contact?.let { c -> item { ContactCorrelationCard(c) } }
                SearchMode.IP -> result.ip?.let { i -> item { IpResultCard(i) } }
                SearchMode.USERNAME -> result.username?.let { u ->
                    item { UsernameSummary(u) }
                    items(u.profiles.filter { it.state != ProbeState.NOT_FOUND }) { hit -> ProfileCard(hit) }
                    val missing = u.profiles.count { it.state == ProbeState.NOT_FOUND }
                    if (missing > 0) item { Text("$missing kaynakta hesap bulunamadı.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)) }
                }
            }
        }
    }
}

@Composable
private fun PhoneResultCard(p: PhoneIntel) {
    val context = LocalContext.current
    ResultCard("Telefon analizi", Icons.Default.Phone) {
        KeyValue("Geçerli", if (p.valid) "Evet" else "Hayır")
        KeyValue("Olası", if (p.possible) "Evet" else "Hayır")
        if (p.international.isNotBlank()) KeyValue("Uluslararası", p.international)
        if (p.e164.isNotBlank()) KeyValue("E.164", p.e164)
        if (p.regionCode.isNotBlank()) KeyValue("Ülke/bölge", p.regionCode)
        if (p.type.isNotBlank()) KeyValue("Hat türü", p.type)
        if (p.carrier.isNotBlank()) KeyValue("Operatör sinyali", p.carrier)
        if (p.geographicDescription.isNotBlank()) KeyValue("Numara bölgesi", p.geographicDescription)
        if (p.timeZones.isNotEmpty()) KeyValue("Saat dilimi", p.timeZones.joinToString())
        p.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        p.webPivots.forEach { (name, url) ->
            OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text(name)
            }
        }
        Text("Operatör/bölge bilgisi numara bloklarından türetilir; kişinin canlı konumu değildir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
    }
}

@Composable
private fun EmailResultCard(e: EmailIntel) {
    val context = LocalContext.current
    ResultCard("E-posta analizi", Icons.Default.Email) {
        KeyValue("Geçerli biçim", if (e.valid) "Evet" else "Hayır")
        if (e.domain.isNotBlank()) KeyValue("Alan adı", e.domain)
        if (e.usernameCandidates.isNotEmpty()) KeyValue("Kullanıcı adı adayları", e.usernameCandidates.joinToString())
        e.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        e.webPivots.forEach { (name, url) ->
            OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text(name)
            }
        }
        Text("Web pivotları aramayı sistem tarayıcısında açar; arama motoru sonuçları uygulama tarafından gizlice kazınmaz.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
    }
}

@Composable
private fun ContactCorrelationCard(c: ContactCorrelationIntel) {
    val context = LocalContext.current
    ResultCard("E-posta ↔ Telefon korelasyonu", Icons.Default.SyncAlt) {
        KeyValue("Yön", c.direction.label)
        KeyValue("Normalize giriş", c.normalizedInput)
        if (c.providerHint.isNotBlank()) KeyValue("Sağlayıcı/operatör", c.providerHint)
        if (c.usernameCandidates.isNotEmpty()) KeyValue("Kullanıcı adı adayları", c.usernameCandidates.joinToString())
        if (c.phoneVariants.isNotEmpty()) KeyValue("Numara varyasyonları", c.phoneVariants.joinToString())
        c.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        c.searchPivots.forEach { (name, url) ->
            OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null)
                Spacer(Modifier.width(8.dp))
                Text(name)
            }
        }
        c.notes.forEach { Text("• $it", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)) }
    }
}

@Composable
private fun IpResultCard(i: IpIntel) {
    ResultCard("IP analizi", Icons.Default.Language) {
        if (!i.success) Text(i.note, color = MaterialTheme.colorScheme.error)
        else {
            KeyValue("IP", i.ip)
            KeyValue("Konum", listOf(i.city, i.region, i.country).filter { it.isNotBlank() }.joinToString(", "))
            KeyValue("ISP", i.isp)
            KeyValue("ASN", i.asn)
            if (i.latitude != null && i.longitude != null) KeyValue("Yaklaşık koordinat", "${i.latitude}, ${i.longitude}")
            Text(i.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
        }
    }
}

@Composable
private fun UsernameSummary(u: UsernameIntel) {
    ResultCard("Kullanıcı adı özeti", Icons.Default.PersonSearch) {
        val confirmed = u.profiles.count { it.state == ProbeState.CONFIRMED }
        val likely = u.profiles.count { it.state == ProbeState.LIKELY }
        val ambiguous = u.profiles.count { it.state == ProbeState.AMBIGUOUS }
        KeyValue("Kaynak denemesi", u.sourcesAttempted.toString())
        KeyValue("Doğrulanan", confirmed.toString())
        KeyValue("Muhtemel", likely.toString())
        KeyValue("Belirsiz", ambiguous.toString())
        if (u.displayNames.isNotEmpty()) KeyValue("Görünen adlar", u.displayNames.joinToString())
        if (u.publicEmails.isNotEmpty()) KeyValue("Açık e-posta", u.publicEmails.joinToString())
        if (u.publicPhones.isNotEmpty()) KeyValue("Açık telefon", u.publicPhones.joinToString())
        if (u.locationSignals.isNotEmpty()) KeyValue("Açık konum sinyali", u.locationSignals.joinToString())
        Text("Varyasyonlar: ${u.variants.joinToString()}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
    }
}

@Composable
private fun ProfileCard(hit: ProfileHit) {
    val context = LocalContext.current
    OutlinedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(hit.source.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                StatusBadge(hit.state, hit.confidence)
            }
            Text("@${hit.username}", color = MaterialTheme.colorScheme.primary)
            Text(hit.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            hit.clues.displayName?.let { if (it.isNotBlank()) KeyValue("Görünen ad", it) }
            if (hit.clues.emails.isNotEmpty()) KeyValue("Açık e-posta", hit.clues.emails.joinToString())
            if (hit.clues.phones.isNotEmpty()) KeyValue("Açık telefon", hit.clues.phones.joinToString())
            if (hit.clues.locations.isNotEmpty()) KeyValue("Konum sinyali", hit.clues.locations.joinToString())
            Text("HTTP ${hit.httpCode ?: "-"} • ${hit.latencyMs} ms", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .45f))
            OutlinedButton(onClick = { openUrl(context, hit.finalUrl) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Kaynağı aç")
            }
        }
    }
}

@Composable
private fun StatusBadge(state: ProbeState, confidence: Confidence) {
    val (text, color) = when (state) {
        ProbeState.CONFIRMED -> "Doğrulandı" to Color(0xFF37E7A1)
        ProbeState.LIKELY -> "Muhtemel" to Color(0xFF25C7FF)
        ProbeState.AMBIGUOUS -> "Belirsiz" to Color(0xFFFFC857)
        ProbeState.BLOCKED -> "Tarayıcı doğrulaması" to Color(0xFFFF9F43)
        ProbeState.ERROR -> "Hata" to Color(0xFFFF6B6B)
        ProbeState.NOT_FOUND -> "Yok" to Color.Gray
    }
    Surface(color = color.copy(alpha = .14f), shape = RoundedCornerShape(999.dp)) {
        Text("$text · ${confidence.label}", Modifier.padding(horizontal = 9.dp, vertical = 4.dp), fontSize = 10.sp, color = color)
    }
}

@Composable
private fun ResultCard(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .35f))
            content()
        }
    }
}

@Composable
private fun KeyValue(key: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(key, modifier = Modifier.width(118.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
        Text(value, modifier = Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CorrelationScreen(result: SearchBundle?) {
    val username = result?.username
    if (username == null) {
        EmptyState(Icons.Default.Hub, "Korelasyon için önce kullanıcı adı araştırması yapın.")
        return
    }
    val pairs = remember(username) { CorrelationEngine.pairwise(username.profiles).filter { it.score > 0 } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Kimlik korelasyonu", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Skor, aynı kişi olduğunu kanıtlamaz; ortak açık kaynak sinyallerinin gücünü özetler.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
        }
        if (pairs.isEmpty()) item { EmptyCard("Yeterli ortak sinyal bulunmadı.") }
        items(pairs.take(50)) { pair ->
            OutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${pair.left.source.name} ↔ ${pair.right.source.name}", fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = pair.score / 100f, modifier = Modifier.fillMaxWidth())
                    Text("Eşleşme sinyali: %${pair.score}", color = MaterialTheme.colorScheme.primary)
                    pair.reasons.forEach { Text("• $it", fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun ReportScreen(result: SearchBundle?) {
    val context = LocalContext.current
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && result != null) runCatching { ReportWriter(context).writePdf(uri, result) }
    }
    val jsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null && result != null) runCatching { ReportWriter(context).writeJson(uri, result) }
    }
    if (result == null) {
        EmptyState(Icons.Default.Description, "Rapor oluşturmak için önce bir araştırma yapın.")
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Raporlama", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        InfoCard("Aktif araştırma", "${result.mode.label}: ${result.query}", Icons.Default.FactCheck)
        Button(onClick = { pdfLauncher.launch("TraceScope_${result.mode.name}_${safeName(result.query)}.pdf") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("PDF raporu kaydet")
        }
        OutlinedButton(onClick = { jsonLauncher.launch("TraceScope_${result.mode.name}_${safeName(result.query)}.json") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.DataObject, null); Spacer(Modifier.width(8.dp)); Text("JSON delil çıktısı kaydet")
        }
        Text("Rapor; sorgu, kaynak URL'leri, durum/güven sınıfları ve tespit edilen kamuya açık sinyalleri içerir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Gizlilik ve güvenilirlik", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { InfoCard("Geçmiş kapalı", "TraceScope v1.0.1 araştırma geçmişini otomatik olarak cihazda saklamaz. Rapor yalnızca siz dışa aktardığınızda yazılır.", Icons.Default.Lock) }
        item { InfoCard("HTTPS zorunlu", "Uygulama cleartext HTTP trafiğini kapatır. Kaynak adaptörleri HTTPS kullanır.", Icons.Default.Https) }
        item { InfoCard("Hata izolasyonu", "Bir kaynak engeller veya hata verirse diğer kaynaklar taranmaya devam eder. Sonuç, 'Hata' veya 'Tarayıcı doğrulaması' şeklinde açıkça işaretlenir.", Icons.Default.HealthAndSafety) }
        item { InfoCard("Sınırlar", "Gizli kayıt e-postası/telefonu, OTP atlatma, özel mesaj, parola, canlı konum veya erişim kontrolü aşma işlevi yoktur.", Icons.Default.Policy) }
        item { InfoCard("Sürüm", "TraceScope OSINT Pro 1.0.1", Icons.Default.Info) }
    }
}

@Composable
private fun EmptyState(icon: ImageVector, text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Icon(icon, null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .7f))
            Spacer(Modifier.height(12.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
    }
}

@Composable
private fun EmptyCard(text: String) {
    OutlinedCard(Modifier.fillMaxWidth()) { Text(text, Modifier.padding(16.dp)) }
}

private fun placeholderFor(mode: SearchMode): String = when (mode) {
    SearchMode.PHONE -> "+90 5xx xxx xx xx"
    SearchMode.USERNAME -> "Kullanıcı adı"
    SearchMode.EMAIL -> "ornek@alanadi.com"
    SearchMode.CONTACT_LINK -> "Telefon numarası veya e-posta"
    SearchMode.IP -> "8.8.8.8"
}

private fun iconFor(mode: SearchMode): ImageVector = when (mode) {
    SearchMode.PHONE -> Icons.Default.Phone
    SearchMode.USERNAME -> Icons.Default.PersonSearch
    SearchMode.EMAIL -> Icons.Default.Email
    SearchMode.CONTACT_LINK -> Icons.Default.SyncAlt
    SearchMode.IP -> Icons.Default.Language
}

private fun openUrl(context: android.content.Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun safeName(value: String): String = value.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40)
