package com.tracescope.osint

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tracescope.osint.engine.EmailEngine
import com.tracescope.osint.engine.ContactCorrelationEngine
import com.tracescope.osint.engine.IpEngine
import com.tracescope.osint.engine.PhoneEngine
import com.tracescope.osint.engine.UsernameEngine
import com.tracescope.osint.model.SearchBundle
import com.tracescope.osint.model.SearchMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SearchUiState(
    val mode: SearchMode = SearchMode.USERNAME,
    val query: String = "",
    val deepScan: Boolean = true,
    val loading: Boolean = false,
    val message: String? = null,
    val result: SearchBundle? = null
)

class TraceScopeViewModel : ViewModel() {
    private val phoneEngine = PhoneEngine()
    private val usernameEngine = UsernameEngine()
    private val ipEngine = IpEngine()

    var state = androidx.compose.runtime.mutableStateOf(SearchUiState())
        private set

    fun setMode(mode: SearchMode) { state.value = state.value.copy(mode = mode, result = null, message = null) }
    fun setQuery(value: String) { state.value = state.value.copy(query = value) }
    fun setDeepScan(value: Boolean) { state.value = state.value.copy(deepScan = value) }

    fun search() {
        val s = state.value
        if (s.query.isBlank()) {
            state.value = s.copy(message = "Aranacak değeri girin")
            return
        }
        state.value = s.copy(loading = true, message = null, result = null)
        viewModelScope.launch {
            val result = try {
                when (s.mode) {
                    SearchMode.PHONE -> withContext(Dispatchers.Default) {
                        SearchBundle(s.mode, s.query, phone = phoneEngine.analyze(s.query))
                    }
                    SearchMode.USERNAME -> SearchBundle(s.mode, s.query, username = usernameEngine.analyze(s.query, s.deepScan))
                    SearchMode.EMAIL -> withContext(Dispatchers.Default) {
                        SearchBundle(s.mode, s.query, email = EmailEngine.analyze(s.query))
                    }
                    SearchMode.CONTACT_LINK -> withContext(Dispatchers.Default) {
                        SearchBundle(s.mode, s.query, contact = ContactCorrelationEngine.analyze(s.query))
                    }
                    SearchMode.IP -> withContext(Dispatchers.IO) {
                        SearchBundle(s.mode, s.query, ip = ipEngine.analyze(s.query))
                    }
                }
            } catch (t: Throwable) {
                null
            }
            state.value = if (result == null) {
                state.value.copy(loading = false, message = "Araştırma tamamlanamadı. İnternet bağlantısını kontrol edin.")
            } else {
                state.value.copy(loading = false, result = result)
            }
        }
    }
}
