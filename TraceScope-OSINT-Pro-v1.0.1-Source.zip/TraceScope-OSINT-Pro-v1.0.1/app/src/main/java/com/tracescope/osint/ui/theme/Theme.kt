package com.tracescope.osint.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF25C7FF),
    secondary = Color(0xFF8B5CFF),
    tertiary = Color(0xFF37E7A1),
    background = Color(0xFF06101A),
    surface = Color(0xFF0B1926),
    surfaceVariant = Color(0xFF102235),
    onPrimary = Color(0xFF00131B),
    onBackground = Color(0xFFE7F4FF),
    onSurface = Color(0xFFE7F4FF),
    outline = Color(0xFF29455E)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF006A8A),
    secondary = Color(0xFF6750A4),
    tertiary = Color(0xFF006C4C),
    background = Color(0xFFF5FAFE),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE3F0F8)
)

@Composable
fun TraceScopeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else DarkColors,
        typography = Typography(),
        content = content
    )
}
