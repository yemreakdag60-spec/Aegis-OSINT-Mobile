package com.tracescope.osint.engine

import com.tracescope.osint.model.*
import com.google.i18n.phonenumbers.PhoneNumberToCarrierMapper
import com.google.i18n.phonenumbers.PhoneNumberToTimeZonesMapper
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.google.i18n.phonenumbers.geocoding.PhoneNumberOfflineGeocoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.system.measureTimeMillis

class NetworkClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    data class FetchResult(
        val code: Int?,
        val body: String,
        val finalUrl: String,
        val latencyMs: Long,
        val error: String? = null
    )

    fun get(url: String): FetchResult {
        var result: FetchResult? = null
        val elapsed = measureTimeMillis {
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36 TraceScopeOSINT/1.0")
                    .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                    .get()
                    .build()
                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty().take(350_000)
                    result = FetchResult(response.code, text, response.request.url.toString(), 0)
                }
            } catch (t: Throwable) {
                result = FetchResult(null, "", url, 0, t.message ?: t.javaClass.simpleName)
            }
        }
        return result!!.copy(latencyMs = elapsed)
    }
}

object SourceRegistry {
    val sources = listOf(
        PlatformSource("GitHub", "https://github.com/%s", true, listOf("Page not found · GitHub")),
        PlatformSource("GitLab", "https://gitlab.com/%s", true, listOf("The page could not be found")),
        PlatformSource("Keybase", "https://keybase.io/%s", true, listOf("User not found")),
        PlatformSource("DEV", "https://dev.to/%s", true, listOf("Page not found")),
        PlatformSource("Medium", "https://medium.com/@%s", false, listOf("PAGE NOT FOUND", "Page not found")),
        PlatformSource("Reddit", "https://www.reddit.com/user/%s/", false, listOf("page not found", "Sorry, nobody on Reddit goes by that name")),
        PlatformSource("Telegram", "https://t.me/%s", false, emptyList()),
        PlatformSource("Instagram", "https://www.instagram.com/%s/", false, listOf("Sorry, this page isn't available", "Page Not Found")),
        PlatformSource("X", "https://x.com/%s", false, listOf("This account doesn’t exist", "Account suspended")),
        PlatformSource("TikTok", "https://www.tiktok.com/@%s", false, listOf("Couldn't find this account", "Page not available")),
        PlatformSource("YouTube", "https://www.youtube.com/@%s", false, listOf("404 Not Found", "This page isn't available")),
        PlatformSource("Twitch", "https://www.twitch.tv/%s", false, listOf("Sorry. Unless you’ve got a time machine")),
        PlatformSource("Pinterest", "https://www.pinterest.com/%s/", false, listOf("Sorry, we couldn't find that page")),
        PlatformSource("SoundCloud", "https://soundcloud.com/%s", false, listOf("We can’t find that user")),
        PlatformSource("Vimeo", "https://vimeo.com/%s", false, listOf("Sorry, we couldn’t find that page"))
    )
}

class PhoneEngine {
    private val util = PhoneNumberUtil.getInstance()
    private val carrierMapper = PhoneNumberToCarrierMapper.getInstance()
    private val geocoder = PhoneNumberOfflineGeocoder.getInstance()
    private val tzMapper = PhoneNumberToTimeZonesMapper.getInstance()

    fun analyze(input: String, defaultRegion: String = "TR"): PhoneIntel {
        return try {
            val number = util.parse(input.trim(), defaultRegion)
            val locale = Locale("tr", "TR")
            PhoneIntel(
                input = input,
                valid = util.isValidNumber(number),
                possible = util.isPossibleNumber(number),
                international = util.format(number, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL),
                national = util.format(number, PhoneNumberUtil.PhoneNumberFormat.NATIONAL),
                e164 = util.format(number, PhoneNumberUtil.PhoneNumberFormat.E164),
                regionCode = util.getRegionCodeForNumber(number).orEmpty(),
                countryCode = number.countryCode,
                type = when (util.getNumberType(number)) {
                    PhoneNumberUtil.PhoneNumberType.MOBILE -> "Mobil"
                    PhoneNumberUtil.PhoneNumberType.FIXED_LINE -> "Sabit hat"
                    PhoneNumberUtil.PhoneNumberType.FIXED_LINE_OR_MOBILE -> "Sabit/Mobil"
                    PhoneNumberUtil.PhoneNumberType.TOLL_FREE -> "Ücretsiz hat"
                    PhoneNumberUtil.PhoneNumberType.PREMIUM_RATE -> "Premium"
                    PhoneNumberUtil.PhoneNumberType.VOIP -> "VoIP"
                    PhoneNumberUtil.PhoneNumberType.PAGER -> "Pager"
                    PhoneNumberUtil.PhoneNumberType.PERSONAL_NUMBER -> "Kişisel numara"
                    else -> "Bilinmiyor"
                },
                carrier = carrierMapper.getNameForNumber(number, locale).orEmpty(),
                geographicDescription = geocoder.getDescriptionForNumber(number, locale).orEmpty(),
                timeZones = tzMapper.getTimeZonesForNumber(number).toList(),
                webPivots = buildPhonePivots(
                    util.format(number, PhoneNumberUtil.PhoneNumberFormat.E164),
                    util.format(number, PhoneNumberUtil.PhoneNumberFormat.NATIONAL),
                    util.format(number, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL)
                )
            )
        } catch (t: Throwable) {
            PhoneIntel(input = input, valid = false, possible = false, error = t.message ?: "Numara çözümlenemedi")
        }
    }

    private fun buildPhonePivots(e164: String, national: String, international: String): List<Pair<String, String>> {
        fun enc(v: String) = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
        val exact = listOf(e164, national, international).filter { it.isNotBlank() }.distinct()
        val ors = exact.joinToString(" OR ") { "\"$it\"" }
        return listOf(
            "Google exact" to "https://www.google.com/search?q=${enc(ors)}",
            "Bing exact" to "https://www.bing.com/search?q=${enc(ors)}",
            "Sosyal profil izi" to "https://www.google.com/search?q=${enc("($ors) (site:instagram.com OR site:x.com OR site:facebook.com OR site:tiktok.com)")}",
            "Web iletişim izi" to "https://www.google.com/search?q=${enc("($ors) (contact OR iletişim OR whatsapp)")}"
        )
    }
}

object EmailEngine {
    private val emailRegex = Regex("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", RegexOption.IGNORE_CASE)

    fun analyze(input: String): EmailIntel {
        val email = input.trim().lowercase()
        if (!emailRegex.matches(email)) return EmailIntel(input, false, error = "Geçerli bir e-posta biçimi girin")
        val local = email.substringBefore('@')
        val domain = email.substringAfter('@')
        val quoted = urlEncode("\"$email\"")
        val pivots = listOf(
            "Google exact" to "https://www.google.com/search?q=$quoted",
            "Bing exact" to "https://www.bing.com/search?q=$quoted",
            "GitHub web" to "https://www.google.com/search?q=${urlEncode("site:github.com \"$email\"")}",
            "Genel profil izi" to "https://www.google.com/search?q=${urlEncode("\"$email\" profile OR contact")}" 
        )
        return EmailIntel(
            input = input,
            valid = true,
            localPart = local,
            domain = domain,
            usernameCandidates = UsernameVariantGenerator.generate(local, limit = 10),
            webPivots = pivots
        )
    }

    private fun urlEncode(v: String): String = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
}

class IpEngine(private val network: NetworkClient = NetworkClient()) {
    fun analyze(input: String): IpIntel {
        val ip = input.trim()
        if (!ip.matches(Regex("^[0-9a-fA-F:.]{3,45}$"))) return IpIntel(input, false, note = "IP biçimi geçersiz")
        val fetch = network.get("https://ipwho.is/${urlEncode(ip)}")
        if (fetch.error != null || fetch.code !in 200..299) return IpIntel(input, false, note = fetch.error ?: "Servis yanıt vermedi")
        return try {
            val o = JSONObject(fetch.body)
            if (!o.optBoolean("success", true)) return IpIntel(input, false, note = o.optString("message", "IP bulunamadı"))
            val conn = o.optJSONObject("connection")
            IpIntel(
                input = input,
                success = true,
                ip = o.optString("ip", ip),
                country = o.optString("country"),
                region = o.optString("region"),
                city = o.optString("city"),
                isp = conn?.optString("isp").orEmpty(),
                asn = conn?.optString("asn").orEmpty(),
                latitude = if (o.has("latitude")) o.optDouble("latitude") else null,
                longitude = if (o.has("longitude")) o.optDouble("longitude") else null,
                note = "IP konumu yaklaşık ağ konumudur; canlı GPS değildir."
            )
        } catch (t: Throwable) {
            IpIntel(input, false, note = "Yanıt çözümlenemedi: ${t.message}")
        }
    }

    private fun urlEncode(v: String): String = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
}

class UsernameEngine(private val network: NetworkClient = NetworkClient()) {
    suspend fun analyze(input: String, deepScan: Boolean = true): UsernameIntel = coroutineScope {
        val firstVariants = UsernameVariantGenerator.generate(input, limit = if (deepScan) 12 else 1)
        val primary = probeVariants(firstVariants.take(if (deepScan) 4 else 1), SourceRegistry.sources)

        val discoveredNames = primary.mapNotNull { it.clues.displayName }.distinct().take(3)
        val allVariants = if (deepScan) UsernameVariantGenerator.generate(input, discoveredNames, limit = 18) else firstVariants
        val extraVariants = allVariants.filterNot { v -> primary.any { it.username == v } }.take(8)
        val highYield = SourceRegistry.sources.filter { it.name in setOf("GitHub", "GitLab", "Keybase", "DEV", "Medium", "Reddit", "Telegram") }
        val extra = if (deepScan && extraVariants.isNotEmpty()) probeVariants(extraVariants, highYield) else emptyList()
        val profiles = (primary + extra)
            .distinctBy { "${it.source.name}|${it.username}" }
            .sortedWith(compareBy<ProfileHit>({ stateRank(it.state) }, { it.confidence.ordinal }, { it.source.name }))

        UsernameIntel(
            input = input,
            variants = allVariants,
            profiles = profiles,
            publicEmails = profiles.flatMap { it.clues.emails }.map { it.lowercase() }.distinct(),
            publicPhones = profiles.flatMap { it.clues.phones }.distinct(),
            locationSignals = profiles.flatMap { it.clues.locations }.distinct(),
            websites = profiles.flatMap { it.clues.websites }.distinct(),
            displayNames = profiles.mapNotNull { it.clues.displayName }.distinct(),
            sourcesAttempted = profiles.size
        )
    }

    private suspend fun probeVariants(variants: List<String>, sources: List<PlatformSource>): List<ProfileHit> = coroutineScope {
        val semaphore = Semaphore(5)
        val jobs = variants.flatMap { username ->
            sources.map { source -> async(Dispatchers.IO) { semaphore.withPermit { probe(source, username) } } }
        }
        jobs.awaitAll()
    }

    private fun probe(source: PlatformSource, username: String): ProfileHit {
        val url = source.urlTemplate.format(username)
        val result = network.get(url)
        if (result.error != null) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.ERROR, Confidence.UNKNOWN, result.code, result.latencyMs, result.error)
        }
        val code = result.code ?: 0
        if (code == 404 || code == 410) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.NOT_FOUND, Confidence.HIGH, code, result.latencyMs, "Bulunamadı")
        }
        if (code == 401 || code == 403 || code == 429) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.BLOCKED, Confidence.UNKNOWN, code, result.latencyMs, "Kaynak otomatik isteği sınırladı; tarayıcıda doğrulanabilir")
        }
        if (code !in 200..399) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.ERROR, Confidence.UNKNOWN, code, result.latencyMs, "HTTP $code")
        }
        val bodyLower = result.body.lowercase()
        val missing = source.notFoundMarkers.any { marker -> bodyLower.contains(marker.lowercase()) }
        if (missing) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.NOT_FOUND, Confidence.HIGH, code, result.latencyMs, "Sayfa yok işareti tespit edildi")
        }

        val clues = PublicIntelExtractor.extract(result.body, result.finalUrl)
        val evidenceMatches = listOfNotNull(clues.displayName, clues.description)
            .joinToString(" ")
            .lowercase()
            .contains(username.lowercase())

        val state = when {
            source.reliableHttp200 && code in 200..299 -> ProbeState.CONFIRMED
            evidenceMatches && code in 200..299 -> ProbeState.LIKELY
            else -> ProbeState.AMBIGUOUS
        }
        val confidence = when (state) {
            ProbeState.CONFIRMED -> Confidence.HIGH
            ProbeState.LIKELY -> Confidence.MEDIUM
            ProbeState.AMBIGUOUS -> Confidence.LOW
            else -> Confidence.UNKNOWN
        }
        val note = when (state) {
            ProbeState.CONFIRMED -> "Kaynakta profil yanıtı doğrulandı"
            ProbeState.LIKELY -> "Profil sinyali bulundu; içerik ile desteklendi"
            ProbeState.AMBIGUOUS -> "HTTP yanıtı var ancak hesap varlığı kesin doğrulanamadı"
            else -> ""
        }
        return ProfileHit(source, username, url, result.finalUrl, state, confidence, code, result.latencyMs, note, clues)
    }

    private fun stateRank(state: ProbeState): Int = when (state) {
        ProbeState.CONFIRMED -> 0
        ProbeState.LIKELY -> 1
        ProbeState.AMBIGUOUS -> 2
        ProbeState.BLOCKED -> 3
        ProbeState.NOT_FOUND -> 4
        ProbeState.ERROR -> 5
    }
}

object PublicIntelExtractor {
    private val emailRegex = Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE)
    private val metaTitle = Regex("(?is)<meta[^>]+(?:property|name)=[\"']og:title[\"'][^>]+content=[\"']([^\"']+)[\"']")
    private val metaDesc = Regex("(?is)<meta[^>]+(?:property|name)=[\"'](?:og:description|description)[\"'][^>]+content=[\"']([^\"']+)[\"']")
    private val canonical = Regex("(?is)<link[^>]+rel=[\"']canonical[\"'][^>]+href=[\"']([^\"']+)[\"']")
    private val titleTag = Regex("(?is)<title[^>]*>(.*?)</title>")
    private val locationJson = Regex("(?i)\"(?:location|addressLocality|addressRegion|addressCountry)\"\\s*:\\s*\"([^\"]{2,100})\"")
    private val homeLocationTitle = Regex("(?is)itemprop=[\"']homeLocation[\"'][^>]*title=[\"']([^\"']{2,100})[\"']")
    private val hrefRegex = Regex("(?is)href=[\"'](https?://[^\"'# ]+)[\"']")

    fun extract(html: String, finalUrl: String): PublicClues {
        if (html.isBlank()) return PublicClues()
        val displayName = decode(metaTitle.find(html)?.groupValues?.getOrNull(1)
            ?: titleTag.find(html)?.groupValues?.getOrNull(1)).takeIf { it.isNotBlank() }
        val description = decode(metaDesc.find(html)?.groupValues?.getOrNull(1)).takeIf { it.isNotBlank() }
        val stripped = stripTags(html).take(120_000)

        val emails = emailRegex.findAll("$description $stripped")
            .map { it.value.lowercase() }
            .filterNot { email ->
                email.endsWith("@example.com") || email.contains("sentry") ||
                    email.substringBefore('@') in setOf("support", "help", "privacy", "security", "noreply", "no-reply")
            }
            .distinct().take(10).toList()

        val phones = runCatching {
            PhoneNumberUtil.getInstance().findNumbers("$description $stripped", "ZZ")
                .map { PhoneNumberUtil.getInstance().format(it.number(), PhoneNumberUtil.PhoneNumberFormat.E164) }
                .filter { it.length in 8..16 }
                .distinct().take(10).toList()
        }.getOrDefault(emptyList())

        val locations = buildList {
            locationJson.findAll(html).map { decode(it.groupValues[1]) }.filter { it.length in 2..100 }.take(8).forEach(::add)
            homeLocationTitle.findAll(html).map { decode(it.groupValues[1]) }.filter { it.length in 2..100 }.take(4).forEach(::add)
        }.distinct()

        val websites = buildList {
            canonical.find(html)?.groupValues?.getOrNull(1)?.let { add(decode(it)) }
            hrefRegex.findAll(html).map { decode(it.groupValues[1]) }
                .filterNot { it.contains("${host(finalUrl)}/") || it.contains("google.com") }
                .take(12).forEach(::add)
        }.distinct()

        return PublicClues(displayName, description, emails, phones, locations, websites)
    }

    private fun host(url: String): String = url.removePrefix("https://").removePrefix("http://").substringBefore('/')
    private fun stripTags(value: String): String = value
        .replace(Regex("(?is)<script.*?</script>"), " ")
        .replace(Regex("(?is)<style.*?</style>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace(Regex("\\s+"), " ")

    private fun decode(value: String?): String = value.orEmpty()
        .replace("&amp;", "&").replace("&quot;", "\"")
        .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
        .trim()
}
