# Aegis OSINT Mobile v1.0.0

Android için kaynak-temelli, kamuya açık veri odaklı OSINT uygulaması.

> Konsept arayüz görseli kaynak ZIP içindeki `docs/` klasöründedir.

## Temel mantık

Aegis, tek bir HTTP 200 yanıtını "hesap bulundu" saymaz. Her platform sonucu `Doğrulandı / Muhtemel / Belirsiz / Tarayıcı doğrulaması / Bulunamadı / Hata` olarak sınıflandırılır. Bir kaynak başarısız olduğunda diğerleri devam eder.

### Modüller

- **Telefon:** libphonenumber ile doğrulama, E.164/ulusal/uluslararası biçim, hat türü, bölge, taşıyıcı ve saat dilimi sinyalleri.
- **Kullanıcı adı:** 15 ana platform, akıllı varyasyonlar, derin ikinci tur tarama, açık profil metadatasından e-posta/telefon/konum/web sinyali çıkarımı.
- **E-posta:** biçim ve alan adı analizi, kullanıcı adı adayları, kullanıcı tarafından açılan exact-search web pivotları.
- **IP:** yalnızca zaten bilinen IP için HTTPS üzerinden yaklaşık ağ konumu/ISP/ASN. Telefon numarasından IP türetmez.
- **Korelasyon:** ortak açık e-posta/telefon, web alan adı, görünen ad, kullanıcı adı benzerliği ve konum sinyallerinden açıklanabilir skor.
- **Rapor:** PDF ve JSON dışa aktarma.

## Güvenlik ve gizlilik

- Yalnızca `INTERNET` izni.
- Cleartext HTTP kapalı.
- Otomatik arama geçmişi yok.
- Bir platform otomasyonu engellerse erişim kontrolünü aşmaya çalışmaz; sonucu tarayıcı doğrulamasına bırakır.
- Gizli kayıt e-postası/telefonu, parola/OTP, özel mesaj, canlı GPS veya kimlik doğrulama aşma özelliği yoktur.

## GitHub Actions ile APK

Projeyi bir GitHub deposuna yükleyin. `.github/workflows/android.yml` otomatik olarak:

1. JDK 17 kurar.
2. Gradle 8.9 wrapper üretir.
3. Unit testleri çalıştırır.
4. Android Lint çalıştırır.
5. Debug APK oluşturur.
6. `Aegis-OSINT-v1.0.0-Debug-APK` adıyla Artifact olarak yükler.

APK yolu: `app/build/outputs/apk/debug/app-debug.apk`

## Yerel geliştirme

Android Studio'da projeyi açın. JDK 17 kullanın. İlk senkronizasyonda Gradle/Maven bağımlılıkları indirilir.

## Lisans notu

Bu proje GhostTrack/PhoneInfoga/Sherlock/Maigret kodlarını kopyalamaz. Yalnızca benzer açık-kaynak araştırma fikirlerini native Android mimarisiyle yeniden uygular. Google libphonenumber (Apache-2.0), OkHttp (Apache-2.0) ve AndroidX/Compose bağımlılıklarını kullanır.
