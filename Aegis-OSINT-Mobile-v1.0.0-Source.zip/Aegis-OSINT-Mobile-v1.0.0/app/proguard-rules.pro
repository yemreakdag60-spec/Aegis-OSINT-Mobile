# Aegis OSINT keeps its model classes simple and does not use reflection-based serialization.
-dontwarn org.conscrypt.**
