package com.aegis.osint.model

enum class SearchMode(val label: String) {
    PHONE("Telefon"), USERNAME("Kullanıcı adı"), EMAIL("E-posta"), IP("IP")
}

enum class ProbeState {
    CONFIRMED, LIKELY, AMBIGUOUS, NOT_FOUND, BLOCKED, ERROR
}

enum class Confidence(val label: String) {
    HIGH("Yüksek"), MEDIUM("Orta"), LOW("Düşük"), UNKNOWN("Belirsiz")
}

data class PlatformSource(
    val name: String,
    val urlTemplate: String,
    val reliableHttp200: Boolean = false,
    val notFoundMarkers: List<String> = emptyList()
)

data class PublicClues(
    val displayName: String? = null,
    val description: String? = null,
    val emails: List<String> = emptyList(),
    val phones: List<String> = emptyList(),
    val locations: List<String> = emptyList(),
    val websites: List<String> = emptyList()
)

data class ProfileHit(
    val source: PlatformSource,
    val username: String,
    val url: String,
    val finalUrl: String,
    val state: ProbeState,
    val confidence: Confidence,
    val httpCode: Int?,
    val latencyMs: Long,
    val note: String,
    val clues: PublicClues = PublicClues()
)

data class PhoneIntel(
    val input: String,
    val valid: Boolean,
    val possible: Boolean,
    val international: String = "",
    val national: String = "",
    val e164: String = "",
    val regionCode: String = "",
    val countryCode: Int = 0,
    val type: String = "",
    val carrier: String = "",
    val geographicDescription: String = "",
    val timeZones: List<String> = emptyList(),
    val webPivots: List<Pair<String, String>> = emptyList(),
    val error: String? = null
)

data class EmailIntel(
    val input: String,
    val valid: Boolean,
    val localPart: String = "",
    val domain: String = "",
    val usernameCandidates: List<String> = emptyList(),
    val webPivots: List<Pair<String, String>> = emptyList(),
    val error: String? = null
)

data class IpIntel(
    val input: String,
    val success: Boolean,
    val ip: String = "",
    val country: String = "",
    val region: String = "",
    val city: String = "",
    val isp: String = "",
    val asn: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val note: String = ""
)

data class UsernameIntel(
    val input: String,
    val variants: List<String>,
    val profiles: List<ProfileHit>,
    val publicEmails: List<String>,
    val publicPhones: List<String>,
    val locationSignals: List<String>,
    val websites: List<String>,
    val displayNames: List<String>,
    val sourcesAttempted: Int
)

data class SearchBundle(
    val mode: SearchMode,
    val query: String,
    val startedAtEpochMs: Long = System.currentTimeMillis(),
    val phone: PhoneIntel? = null,
    val email: EmailIntel? = null,
    val ip: IpIntel? = null,
    val username: UsernameIntel? = null
)

data class CorrelationPair(
    val left: ProfileHit,
    val right: ProfileHit,
    val score: Int,
    val reasons: List<String>
)
