package com.aegis.osint.report

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.aegis.osint.model.SearchBundle
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportWriter(private val context: Context) {
    fun writeJson(uri: Uri, bundle: SearchBundle) {
        val root = JSONObject().apply {
            put("application", "Aegis OSINT")
            put("version", "1.0.0")
            put("generatedAt", isoDate())
            put("mode", bundle.mode.name)
            put("query", bundle.query)
            bundle.phone?.let { p ->
                put("phone", JSONObject().apply {
                    put("valid", p.valid); put("possible", p.possible); put("international", p.international)
                    put("national", p.national); put("e164", p.e164); put("regionCode", p.regionCode)
                    put("countryCode", p.countryCode); put("type", p.type); put("carrier", p.carrier)
                    put("geographicDescription", p.geographicDescription); put("timeZones", JSONArray(p.timeZones))
                    put("webPivots", JSONArray().apply { p.webPivots.forEach { put(JSONObject().apply { put("name", it.first); put("url", it.second) }) } })
                    put("error", p.error)
                })
            }
            bundle.email?.let { e ->
                put("email", JSONObject().apply {
                    put("valid", e.valid); put("domain", e.domain); put("localPart", e.localPart)
                    put("usernameCandidates", JSONArray(e.usernameCandidates))
                })
            }
            bundle.ip?.let { i ->
                put("ip", JSONObject().apply {
                    put("success", i.success); put("ip", i.ip); put("country", i.country); put("region", i.region)
                    put("city", i.city); put("isp", i.isp); put("asn", i.asn); put("latitude", i.latitude); put("longitude", i.longitude)
                    put("note", i.note)
                })
            }
            bundle.username?.let { u ->
                put("username", JSONObject().apply {
                    put("variants", JSONArray(u.variants)); put("publicEmails", JSONArray(u.publicEmails))
                    put("publicPhones", JSONArray(u.publicPhones)); put("locationSignals", JSONArray(u.locationSignals))
                    put("websites", JSONArray(u.websites)); put("displayNames", JSONArray(u.displayNames))
                    put("profiles", JSONArray().apply {
                        u.profiles.forEach { hit ->
                            put(JSONObject().apply {
                                put("source", hit.source.name); put("username", hit.username); put("url", hit.url)
                                put("finalUrl", hit.finalUrl); put("state", hit.state.name); put("confidence", hit.confidence.name)
                                put("httpCode", hit.httpCode); put("latencyMs", hit.latencyMs); put("note", hit.note)
                                put("displayName", hit.clues.displayName); put("description", hit.clues.description)
                                put("emails", JSONArray(hit.clues.emails)); put("phones", JSONArray(hit.clues.phones))
                                put("locations", JSONArray(hit.clues.locations)); put("websites", JSONArray(hit.clues.websites))
                            })
                        }
                    })
                })
            }
        }
        context.contentResolver.openOutputStream(uri)?.use { it.write(root.toString(2).toByteArray()) }
    }

    fun writePdf(uri: Uri, bundle: SearchBundle) {
        val doc = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f }
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 20f; isFakeBoldText = true }
        val pageWidth = 595
        val pageHeight = 842
        val margin = 40f
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = doc.startPage(pageInfo)
        var canvas = page.canvas
        var y = 55f

        fun newPage() {
            doc.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            page = doc.startPage(pageInfo)
            canvas = page.canvas
            y = 50f
        }

        fun line(text: String, bold: Boolean = false) {
            val p = if (bold) Paint(paint).apply { isFakeBoldText = true } else paint
            val words = text.replace("\n", " ").split(Regex("\\s+"))
            var current = ""
            val maxWidth = pageWidth - margin * 2
            words.forEach { word ->
                val next = if (current.isBlank()) word else "$current $word"
                if (p.measureText(next) > maxWidth && current.isNotBlank()) {
                    if (y > pageHeight - 45) newPage()
                    canvas.drawText(current, margin, y, p); y += 16f; current = word
                } else current = next
            }
            if (current.isNotBlank()) {
                if (y > pageHeight - 45) newPage()
                canvas.drawText(current, margin, y, p); y += 16f
            }
        }

        canvas.drawText("Aegis OSINT Raporu", margin, y, title); y += 28f
        line("Oluşturulma: ${humanDate()}")
        line("Araştırma türü: ${bundle.mode.label}")
        line("Sorgu: ${bundle.query}", true)
        y += 8f

        bundle.phone?.let { p ->
            line("Telefon Analizi", true)
            line("Geçerli: ${p.valid} | Olası: ${p.possible}")
            line("Uluslararası: ${p.international}")
            line("E164: ${p.e164} | Bölge: ${p.regionCode} | Tür: ${p.type}")
            if (p.carrier.isNotBlank()) line("Operatör sinyali: ${p.carrier}")
            if (p.geographicDescription.isNotBlank()) line("Numara bölgesi: ${p.geographicDescription}")
            if (p.timeZones.isNotEmpty()) line("Saat dilimleri: ${p.timeZones.joinToString()}")
            p.error?.let { line("Hata: $it") }
        }

        bundle.email?.let { e ->
            line("E-posta Analizi", true)
            line("Geçerli: ${e.valid} | Alan adı: ${e.domain}")
            line("Kullanıcı adı adayları: ${e.usernameCandidates.joinToString()}")
        }

        bundle.ip?.let { i ->
            line("IP Analizi", true)
            line("${i.ip} — ${i.city}, ${i.region}, ${i.country}")
            line("ISP: ${i.isp} | ASN: ${i.asn}")
            line(i.note)
        }

        bundle.username?.let { u ->
            line("Kullanıcı Adı Analizi", true)
            line("Varyasyonlar: ${u.variants.joinToString()}")
            line("Denenen kaynak: ${u.sourcesAttempted}")
            if (u.publicEmails.isNotEmpty()) line("Açık e-postalar: ${u.publicEmails.joinToString()}")
            if (u.publicPhones.isNotEmpty()) line("Açık telefonlar: ${u.publicPhones.joinToString()}")
            if (u.locationSignals.isNotEmpty()) line("Açık konum sinyalleri: ${u.locationSignals.joinToString()}")
            y += 6f
            u.profiles.filter { it.state.name != "NOT_FOUND" }.forEach { hit ->
                line("${hit.source.name} @${hit.username} — ${hit.state} / ${hit.confidence}", true)
                line(hit.finalUrl)
                line(hit.note)
                hit.clues.displayName?.let { line("Görünen ad: $it") }
                hit.clues.description?.takeIf { it.isNotBlank() }?.let { line("Açıklama: $it") }
                y += 4f
            }
        }

        y += 8f
        line("Not: Bu rapor yalnızca kamuya açık kaynak sinyallerini içerir. Gizli kayıt e-postası/telefonu veya canlı konum çıkarmaz.")
        doc.finishPage(page)
        context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        doc.close()
    }

    private fun isoDate(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date())
    private fun humanDate(): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date())
}
