package com.aegis.osint.engine

import com.aegis.osint.model.*
import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test
    fun usernameVariantsContainUsefulForms() {
        val v = UsernameVariantGenerator.generate("Emre.Akdag")
        assertTrue(v.contains("emre.akdag"))
        assertTrue(v.contains("emreakdag"))
        assertTrue(v.contains("akdagemre"))
    }

    @Test
    fun correlationRewardsSharedPublicEmail() {
        val s1 = PlatformSource("A", "https://a/%s")
        val s2 = PlatformSource("B", "https://b/%s")
        val a = ProfileHit(s1, "user.one", "", "", ProbeState.LIKELY, Confidence.MEDIUM, 200, 10, "", PublicClues(displayName = "User One", emails = listOf("same@example.org")))
        val b = ProfileHit(s2, "user_one", "", "", ProbeState.LIKELY, Confidence.MEDIUM, 200, 10, "", PublicClues(displayName = "User One", emails = listOf("same@example.org")))
        val pair = CorrelationEngine.pairwise(listOf(a, b)).first()
        assertTrue(pair.score >= 50)
        assertTrue(pair.reasons.any { it.contains("e-posta") })
    }
}
