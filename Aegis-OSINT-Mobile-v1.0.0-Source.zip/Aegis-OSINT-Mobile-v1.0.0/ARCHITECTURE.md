# Aegis OSINT v1.0.0 — Mimari

## Güvenilirlik ilkeleri

1. **Fail-open değil, fail-visible:** Kaynak hatası gizlenmez; `ERROR/BLOCKED` olur.
2. **Tek sinyal = kimlik değil:** Kullanıcı adı benzerliği tek başına güçlü korelasyon sayılmaz.
3. **Public-only:** Yalnızca herkese açık HTTP içeriği veya kullanıcı tarafından açılan web aramaları.
4. **No bypass:** 401/403/429 durumlarında erişim kontrolü aşılmaz.
5. **Explainable scoring:** Korelasyon skoru sebepleriyle gösterilir.
6. **Source traceability:** URL, HTTP kodu, gecikme ve not saklanır/raporlanır.
7. **No secret claims:** Gizli kayıt e-postası/telefonu veya canlı konum varmış gibi sonuç üretilmez.

## Arama akışı

### Kullanıcı adı

`input -> normalize -> 1. tur platform tarama -> metadata çıkarımı -> görünen adlardan yeni varyasyonlar -> yüksek verimli kaynaklarda 2. tur -> dedupe -> confidence -> correlation`

Derin tarama, istek sayısını sınırlamak için ikinci turu yalnızca GitHub/GitLab/Keybase/DEV/Medium/Reddit/Telegram gibi yüksek verimli kaynaklara uygular.

### Telefon

`input -> libphonenumber parse -> validation -> type/region/carrier/geocoder/timezone`

Bu bilgiler numara bloklarının metadata'sıdır, abone kimliği veya canlı konum değildir.

### E-posta

`syntax -> local-part -> username variants -> browser-assisted exact web pivots`

### IP

`known IP -> ipwho.is HTTPS -> approximate network geolocation`
